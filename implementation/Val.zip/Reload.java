/**
* Author: Kieran Lee
* Date: Jan 27th 2022
* Class: Reload
* Purpose: To reload the ammo
*/

import java.util.*;
public class Reload extends Weapon { 

  Scanner in = new Scanner(System.in); 
  private int re;
  int ogAmmo;

  public Reload (String name, int damage, int range, int ammo) {
    super(name, damage, range, ammo);
  }

  // Acssesors

  // Modifiers

  public int ogAmmo(int ammo)  {
    if (ammo <= 0)  {
      ogAmmo = this.getAmmo();
    }
    return ammo;
  }

  public int reload(int ammo)  {
       System.out.println ("ammo is full again");

       return ammo;
  }

}