/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Knife
* Purpose: One of the 5 weapons provided in this program.
*/

public class Knife extends Weapon {

    /**
    * Creates a knife for the player to use with the given info.
    * Inherits from the weapon class.
    */
    public Knife(String name, int damage, int range, int ammo) {
        super(name, damage, range, ammo);
    }

    //Accessors


    //Mutators

    /**
    * Shoot action
    * Allows player to shoot their weapon.
    * (Technacily a shoot still since it would be the same function in game)
    */
    public void shoot() {
        System.out.println("Stabby stab");
    }
}