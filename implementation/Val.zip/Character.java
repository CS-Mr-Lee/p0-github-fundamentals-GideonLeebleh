/**
* Author: Kieran Lee
* Date: Jan 27th 2022
* Class: Character
* Purpose: Houses all methods and attributes relating to the characters movement and senses
*/

import java.util.Scanner;
public class Character {
    private String name, typeOfAgent;
    private int x,z;
    private int hp;
    int max = 100, min = 1, range = max - min + 1;
    private int enemyX = (int)(Math.random() * range) + min;
    private int enemyZ = (int)(Math.random() * range) + min;
    Scanner in = new Scanner(System.in); 

    public Character() {
      this.name = "none";
      this.typeOfAgent = "none";
      this.x = 50;
      this.z = 50;
      this.hp = 100;
    }

    public Character(String name, String typeOfAgent, int x, int y, int z, int hp) {
        this.name = name;
        this.typeOfAgent = typeOfAgent;
        this.x = x; //(North/South)
        this.z = z; //(East/West)
        this.hp = hp;
    }

    //Accessors

    public String getName() {
        return this.name;
    }

    public String getTypeOfAgent() {
        return this.typeOfAgent;
    }

    public int getX() {
        return this.x;
    }

    public int getZ() {
        return this.z;
    }

    public int getHp() {
        return this.hp;
    }

    //Mutators
    // For when the character sees the enemy
    public void observe() {
        for (int i = 1; i < 6; i++)  {
          int locateEnemyX = this.x + i, locateEnemyZ = this.z + i;
          int locateEnemyX2 = this.x - i, locateEnemyZ2 = this.z - i;

          if ((locateEnemyX == enemyX) || (locateEnemyZ == enemyZ) || (locateEnemyX2 == enemyX) || (locateEnemyZ2 == enemyZ)) {
            System.out.println ("You see an enemy");
          }
        }
        return;
    }

    public void qAbility() {
        System.out.println("?");
    }

     public void eAbility() {
        System.out.println("?");
    }

     public void cAbility() {
        System.out.println("?");
    }

     public void xAbility() {
        System.out.println("?");
    }

    public void setName(String name) {
    this.name = name;
    }

    public void setTypeOfAgent(String typeOfAgent) {
    this.typeOfAgent = typeOfAgent;
    }
    
    public void setHp(int hp) {
      this.hp = hp;
    }

    public void setX(int x) {
       this.x = x;
    }

    public void setZ(int z) {
      this.z = z;
    }

   // Movement
       public void move(String direction) {
      // this is changes the coordinates based ont the input
        switch (direction)  {
          case "forward":  
            this.x++;
            System.out.println ("Coordinates are " + this.x + " and " + this.z);
          break;
          case "downward":
            this.x--;
            System.out.println ("Coordinates are " + x + " and " + z);
          break;
          case "right":
            this.z++;
            System.out.println ("Coordinates are " + x + " and " + z);
          break;
          case "left":
            this.z--;
            System.out.println ("Coordinates are " + x + " and " + z);
          break;
        }
        return;
    }

    // map/boundries for the game
    public void map ()  {
      // if the character reaches the x border
      if (this.x >= 100) {
        this.x = 99;
        System.out.println("You've reached the end of the map");
      } 
      // if the character reaches the z border
      if (this.z >= 100) {
        this.z = 99;  
         System.out.println("You've reached the end of the map");
      }
      // if the character reaches the z boarder
      if (this.z <= 0) {
        this.z = 1;  
         System.out.println("You've reached the end of the map");
      } 
        // if the character reaches the x boarder
        if (this.x <= 0) {
        this.x = 1;  
         System.out.println("You've reached the end of the map");
      }
    }

    public String toString() {
        String ret = "x: " + this.x + " " +
                "z: " + this.z + " " +
                "Hp: " + this.hp;
        return ret;
    }
}