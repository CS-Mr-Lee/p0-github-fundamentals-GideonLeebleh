/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Shotgun
* Purpose: One of the 5 weapons provided in this program.
*/

public class Shotgun extends Weapon {

    /**
    * Creates a knife for the player to use with the given info.
    * Inherits from the weapon class.
    */
    public Shotgun(String name, int damage, int range, int ammo) {
        super(name, damage, range, ammo);
    }

    //Accessors


    //Mutators

    /**
    * Shoot action
    * Allows player to shoot their weapon.
    */
    public void shoot() {
        if (this.getAmmo() > 0)
        {
          this.setAmmo(this.getAmmo() - 1);
          System.out.println("BOOM");
        }
        else if (this.getAmmo() <= 0)
        {
          System.out.println("Nope, reload, you're out of ammo!");
        }
    }
}