/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Shield
* Purpose: To give the character extra health
* (Extends from Kieran's class Character)
*/

public class Shield extends Character {


    public Shield(String name, String typeOfAgent, int x, int y, int z, int hp) {
        super(name, typeOfAgent, x, y, z, hp);
    }

    //Accessors


    //Mutators

    /**
    * Shield action
    * @param health: This is the hp of a character
    *                 to begin with.
    * @return health: By the time the health int gets to the end
    *                 it will have either grown by 50 hp, or stayed
    *                 the same.
    */
    public int shield(int health) {
      if(health <= 100)
      {
        health = (health + 50);
        System.out.println(health);
        System.out.println("You've been sheilded for 50 hp");
        return health;
      }
      else if (health > 100)
      {
       System.out.println("Nope, you're already sheilded");
       return health;
      }
      return health;
    }
}