/**
* Author: Kieran Lee
* Date: Jan 27th 2022
* Class: Jett
* Purpose: One of the 5 agents provided in this program.
*/

public class Jett extends Character {

    /* Creates Jett for the player to use with the given info.
    * Inherits from the character class.
    */
    public Jett(String name, String typeOfAgent, int x, int y, int z, int hp) {
        super(name, typeOfAgent, x, y, z, hp);
    }

    //Accessors


    //Mutators

    /**
    * qAbility action
    * Allows player to use Jett's qAbility.
    */
    public void qAbility() {
        System.out.println("Jett has propelled into the air using Updraft");
    }

    /**
    * eAbility action
    * Allows player to use cypher's qAbility.
    */
     public void eAbility() {
        System.out.println("Jett sped across in a Tailwind");
    }

    /**
    * cAbility action
    * Allows player to use cypher's qAbility.
    */
     public void cAbility() {
        System.out.println("Jett has created a cloudburst");
    }

    /**
    * xAbility action
    * Allows player to use cypher's qAbility.
    */
     public void xAbility() {
        System.out.println("Jett unleashed the Blade Storm");
    }
}