  /**
* Author: Gideon and Kieran Lee
* Date: Jan 27th 2022
* Class: Main
* Purpose: This program is supposed to emulate the game Valorant and 
*          repersent one way the system could be built in a very basic 
*          way.
*/

import java.util.Scanner;

class Main {

  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    String agent;
    String weapon;
    String skin;
    String action;
    String move;
    int ogAmmo = 0;
    boolean gameOn = false;

    /**
    * This is a block of code that sets up all the classes for use
    * in the main class.
    */
    Character player = new Character();
    Shield shield = new Shield("", "", 0, 0, 0, 0);
    Jett jett = new Jett("Jett","1", 0, 0, 0, 100);
    Cypher cypher = new Cypher("Cypher","2", 0, 0, 0, 100);
    Phoenix phoenix = new Phoenix("Phoenix","3", 0, 0, 0, 100);
    Viper viper = new Viper("Viper","4", 0, 0, 0, 100);
    Pistol pistol = new Pistol("pistol", 20, 40, 10);
    Rifle rifle = new Rifle("rifle", 40, 60, 60);
    Knife knife = new Knife("knife", 60, 5, 0);
    Shotgun shotgun = new Shotgun("shotgun", 70, 20, 10);
    Smg smg = new Smg ("smg", 30, 40, 50);
    WeaponSkin image = new WeaponSkin();
    Reload reload = new Reload("", 0, 0, 0);

    /**
    * This is a prompt for info so the program can set up which agent
    * you play as, and what weapon and weapon skin you use.
    */
    System.out.println(""); //space
    System.out.println("Welcome to this wannabe Valorant thing");
    System.out.println("The agents avaible are: Jett, Pheonix, Cypher, and Viper");
    System.out.print("Type in who you want to play as: ");
    agent = in.nextLine();
    System.out.println("The options for weapon are: Knife, pistol, rifle, smg, and shotgun");
    System.out.print("Choose your weapon: ");
    weapon = in.nextLine();
    System.out.println("The skins avaible for this gun are: none, Luxe, Prime, Glitchpop, and Winterwunderland");
    System.out.print("Choose your skin: ");
    skin = in.nextLine();
    image.getSkin(skin);
    
    /**
    * This block is to set up how much ammo the player will have
    * to use and reload up to.
    */
    if (weapon.equalsIgnoreCase("pistol"))
        {
          ogAmmo = pistol.getAmmo();
        }
    else if (weapon.equalsIgnoreCase("rifle"))
        {
          ogAmmo = rifle.getAmmo();
        }
    else if (weapon.equalsIgnoreCase("shotgun"))
        {
          ogAmmo = shotgun.getAmmo();
        }
    else if (weapon.equalsIgnoreCase("smg"))
        {
          ogAmmo = smg.getAmmo();
        }  

   /**
   *  This is where the loop containg the game begins after recieving
   *  all the required info.
   */
    gameOn = true;

    while (gameOn)  {
      
      /**
      * Prompt asking the user what action they want to take next.
      */
      System.out.println("");
      System.out.println("What action do you want to take?");
      System.out.println("(Type 'help' if you dont' know what to do)");
      System.out.println("");
      action = in.nextLine();
      
      /**
      * Shoot action
      * This is the block of code that allows the player to shoot 
      * and or use their weapon, utilizing the shoot method from each
      * weapon subclass except reolad.
      */
      if (action.equalsIgnoreCase("shoot"))
      {
        if (weapon.equalsIgnoreCase("pistol"))
        {
          pistol.shoot();
        }
        
        else if (weapon.equalsIgnoreCase("rifle"))
        {
          rifle.shoot();
        }
        
        else if (weapon.equalsIgnoreCase("knife"))
        {
          knife.shoot();
        }

        else if (weapon.equalsIgnoreCase("shotgun"))
        {
          shotgun.shoot();
        }

        else if (weapon.equalsIgnoreCase("smg"))
        {
          smg.shoot();
        }
      }
      
      /**
      * Reload action
      * Allows the player to reload using the correct value for ammo for
      * each weapon. (Knife isn't here since you can't exactly reload a 
      * knife)
      */
      
      else if (action.equalsIgnoreCase("r"))
      {
        if (weapon.equalsIgnoreCase("pistol"))
        {
          pistol.setAmmo(reload.reload(ogAmmo));
        }
        else if (weapon.equalsIgnoreCase("rifle"))
        {
          rifle.setAmmo(reload.reload(ogAmmo));
        }
        else if (weapon.equalsIgnoreCase("shotgun"))
        {
          shotgun.setAmmo(reload.reload(ogAmmo));
        }
        else if (weapon.equalsIgnoreCase("smg"))
        {
          smg.setAmmo(reload.reload(ogAmmo));
        }
      } 
      
      /**
      * This is a command to give the user a    
        reminder of what 
      * commands they can use.
      */
      else if (action.equalsIgnoreCase("help"))
      {
        System.out.println("Actions you can do include:");
        System.out.println("shoot");
        System.out.println("admire");
        System.out.println("move");
        System.out.println("q");
        System.out.println("e");
        System.out.println("c");
        System.out.println("x");
        System.out.println("shield");
        System.out.println("r");
      }
      
      /**
      * Look at gun action
      * Allows the user to look at the cosmetic        value of their gun. 
      */
      else if (action.equalsIgnoreCase("admire"))
      {
        image.lookAtGun();
      }

      /**
      * Shield action
      * Allows the user to boost their health to a     max of 
      * 150 hp with sheilds
      */ 
      else if (action.equalsIgnoreCase("shield"))
      {
        if (agent.equalsIgnoreCase("Jett"))
        {
          jett.setHp(shield.shield(jett.getHp()));
        }
        else if (agent.equalsIgnoreCase("Cypher"))
        {
          cypher.setHp(shield.shield(cypher.getHp()));
        }
        else if (agent.equalsIgnoreCase("Viper"))
        {
          viper.setHp(shield.shield(viper.getHp()));
        }
        else if (agent.equalsIgnoreCase("Phoenix"))
        {
          phoenix.setHp(shield.shield(phoenix.getHp()));
        }
      }

      /**
      * Move action
      * Allows the player to move around the map       aswell as notice
      * any enemies. It also contains the method for   the map 
      * boundaries.
      */
      else if (action.equalsIgnoreCase("move")) // Movement
      {
        System.out.println("Input a direction with wasd:");
        move = in.nextLine();
        if (move.equalsIgnoreCase("w")) {
          player.move("forward");
        } 
        else if (move.equalsIgnoreCase("s"))  {
          player.move("downward");
        }
        else if (move.equalsIgnoreCase("d"))  {
          player.move("right");
        }
        else if (move.equalsIgnoreCase("a"))  {
          player.move("left");
        }
        
        player.map();
        player.observe();
      }
      
      /**
      * qAbility action
      * Allows players to use whatever ability is assigned
      * to the q key.
      */
      else if (action.equalsIgnoreCase("q"))  {
        if (agent.equalsIgnoreCase("Jett"))
        {
          jett.qAbility();
        }
        else if (agent.equalsIgnoreCase("Cypher"))
        {
          cypher.qAbility();
        }
        else if (agent.equalsIgnoreCase("Viper"))
        {
          viper.qAbility();
        }
        else if (agent.equalsIgnoreCase("Phoenix"))
        {
          phoenix.qAbility();
        }
      }

      /**
      * cAbility action
      * Allows players to use whatever ability is assigned
      * to the c key.
      */
      else if (action.equalsIgnoreCase("c")) {
        if (agent.equalsIgnoreCase("Jett"))
        {
          jett.cAbility();
        }
        else if (agent.equalsIgnoreCase("Cypher"))
        {
          cypher.cAbility();
        }
        else if (agent.equalsIgnoreCase("Viper"))
        {
          viper.cAbility();
        }
        else if (agent.equalsIgnoreCase("Phoenix"))
        {
          phoenix.cAbility();
        }
      }

      /**
      * eAbility action
      * Allows players to use whatever ability is assigned
      * to the e key.
      */
      else if (action.equalsIgnoreCase("e")) {
        if (agent.equalsIgnoreCase("Jett"))
        {
          jett.eAbility();
        }
        else if (agent.equalsIgnoreCase("Cypher"))
        {
          cypher.eAbility();
        }
        else if (agent.equalsIgnoreCase("Viper"))
        {
          viper.eAbility();
        }
        else if (agent.equalsIgnoreCase("Phoenix"))
        {
          phoenix.eAbility();
        }
      }

      /**
      * xAbility action
      * Allows players to use whatever ability is      assigned
      * to the x key.
      */
      else if (action.equalsIgnoreCase("x"))  {
        if (agent.equalsIgnoreCase("Jett"))
        {
          jett.xAbility();
        }
        else if (agent.equalsIgnoreCase("Cypher"))
        {
          cypher.xAbility();
        }
        else if (agent.equalsIgnoreCase("Viper"))
        {
          viper.xAbility();
        }
        else if (agent.equalsIgnoreCase("Phoenix"))
        {
          phoenix.xAbility();
        }
      }
    }
  }
} 
