/**
* Author: Kieran Lee
* Date: Jan 27th 2022
* Class: viper
* Purpose: One of the 5 agents provided in this program.
*/

public class Viper extends Character {

    /* Creates Viper for the player to use with the given info.
    * Inherits from the character class.
    */
    public Viper(String name, String typeOfAgent, int x, int y, int z, int hp) {
        super(name, typeOfAgent, x, y, z, hp);
    }

    //Accessors


    //Mutators
    /**
    * qAbility action
    * Allows player to use Viper's qAbility.
    */
    public void qAbility() {
        System.out.println("Viper has emitted a poison cloud");
    }

    /**
    * eAbility action
    * Allows player to use Viper's qAbility.
    */
     public void eAbility() {
        System.out.println("Viper created a toxic screen");
    }

    /**
    * cAbility action
    * Allows player to use Viper's qAbility.
    */
     public void cAbility() {
        System.out.println("Viper has released the snake bite");
    }

    /**
    * xAbility action
    * Allows player to use Viper's qAbility.
    */
     public void xAbility() {
        System.out.println("Viper has unleashed the Vipers Pit");
    }
}