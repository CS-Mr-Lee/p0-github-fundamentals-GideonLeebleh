/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Weapon
* Purpose: To hold the attributes and methods that create the weapons in Valorant.
*/

public class Weapon {
    private String name;
    private int damage;
    private int range;
    private int ammo;

    /**
    * Creates a blueprint for weapon sublclasses to create different weapons.
    */
    public Weapon(String name, int damage, int range, int ammo) {
        this.name = name;
        this.range = range;
        this.damage = damage;
        this.ammo = ammo;
    }

    //Accessors

    /**
    * Getters
    * Allows user to access private variable info.
    */
    public String getName() {
        return this.name;
    }

    public int getDamage() {
        return this.damage;
    }

    public int getRange() {
        return this.range;
    }

    public int getAmmo() {
        return this.ammo;
    }

    //Mutators

    /**
    * Setters
    * Allows user to set private variable info.
    */
    public void setName(String name) {
      this.name = name;
    }
    
    public void setDamage(int damage) {
      this.damage = damage;
    }

    public void setRange(int range) {
      this.range = range;
    }

    public void setAmmo(int ammo) {
      this.ammo = ammo;
    }


    /**
    * Shoot action
    * Allows player to shoot their weapon.
    */
    public void shoot() {
        System.out.println("????");
    }

    public String toString() {
        String ret = "name: " + this.name + " " +
                "damage: " + this.damage + " " +
                "range: " + this.range + " " +
                "ammo: " + this.ammo;
        return ret;
    }
}