/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Rifle
* Purpose: One of the 5 weapons provided in this program.
*/

public class Rifle extends Weapon {

    /**
    * Creates a rifle for the player to use with the given info.
    * Inherits from the weapon class.
    */
    public Rifle(String name, int damage, int range, int ammo) {
        super(name, damage, range, ammo);
    }

    //Accessors


    //Mutators

    /**
    * Shoot action
    * Allows player to shoot their weapon.
    */
    public void shoot() {
        if (this.getAmmo() > 0)
        {
          this.setAmmo(this.getAmmo() - 30);
          System.out.println("bssh bsssh t-t-t-t-t-t-t-t-t-t-t-- chk chk");
        }
        else if (this.getAmmo() <= 0)
        {
          System.out.println("Nope, reload, you're out of ammo!");
        }
    }
}