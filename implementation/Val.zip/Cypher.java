/**
* Author: Kieran Lee
* Date: Jan 27th 2022
* Class: Cypher
* Purpose: One of the 5 agents provided in this program.
*/

public class Cypher extends Character {

    /**
    * Creates Cypher for the player to use with the given info.
    * Inherits from the character class.
    */
    public Cypher(String name, String typeOfAgent, int x, int y, int z, int hp) {
        super(name, typeOfAgent, x, y, z, hp);
    }

    //Accessors


    //Mutators

    /**
    * qAbility action
    * Allows player to use cypher's qAbility.
    */
    public void qAbility() {
        System.out.println("Cypher throws down a cyber cage");
    }

    /**
    * eAbility action
    * Allows player to use cypher's eAbility.
    */
     public void eAbility() {
        System.out.println("Cypher puts up a spycam");
    }

    /**
    * cAbility action
    * Allows player to use cypher's cAbility.
    */
     public void cAbility() {
        System.out.println("Cypher sets up a trip wire");
    }

    /**
    * xAbility action
    * Allows player to use cypher's xAbility.
    */
     public void xAbility() {
        System.out.println("Cypher throws his hat at a corpse");
    }
}