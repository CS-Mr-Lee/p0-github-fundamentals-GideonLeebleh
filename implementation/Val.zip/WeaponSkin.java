/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: WeaponSkin
* Purpose: To hold the attributes and methods that create the weapon skins in Valorant.
*/

public class WeaponSkin{
    private String name;
    private String rarity;
    private boolean animated;

    public WeaponSkin()
    {
      this.name = "none";
      this.rarity = "common";
      this.animated = false;
    }

    public WeaponSkin(String name, String rarity, boolean animated) 
    {
        this.name = name;
        this.rarity = rarity;
        this.animated = animated;
    }

    //Accessors

    /**
    * Getters
    * @param Getters to access private values.
    */
    public String getName() {
        return this.name;
    }

    public String getRarity() {
        return this.rarity;
    }

    public boolean getAnimated() {
        return this.animated;
    }

    //Mutators

    /**
    * Setters
    * @param Setters to change private values.
    */
    public void setName(String name) {
        this.name = name;
    } 

    public void setRarity(String rarity)
    {
      this.rarity = rarity;
    }

    public void setAnimated(boolean animated) {
        this.animated = animated;
    } 

    /**
    * getSkin
    * @param A giant getter basically
    */
    public void getSkin(String weaponSkin)
    {
      if (weaponSkin.equalsIgnoreCase("none"))
      {
        this.name = "no skin";
        this.rarity = "Common";
        this.animated = false;
      }
      else if (weaponSkin.equalsIgnoreCase("Luxe"))
      {
        this.name = "Luxe";
        this.rarity = "Rare";
        this.animated = false;
      }
      else if (weaponSkin.equalsIgnoreCase("Prime"))
      {
        this.name = "Prime";
        this.rarity = "Rare";
        this.animated = false;
      }
      else if (weaponSkin.equalsIgnoreCase("glitchpop"))
      {
        this.name = "GlitchPop";
        this.rarity = "Very rare";
        this.animated = true;
      }
      else if (weaponSkin.equalsIgnoreCase("Winterwunderland"))
      {
        this.name = "Winterwunderland";
        this.rarity = "Very rare";
        this.animated = true;
      }
    }

    /**
    * lookAtGun
    * @param Let's player look at their gun to see what cosmetic properties it has.
    */
    public void lookAtGun()
    {
      System.out.println("This is the " + this.getName() + " skin");
      System.out.println("This is a " + this.getRarity() + " level skin");
      
      if (this.getAnimated() == true)
      {
        System.out.println("This is an animated weapon");
      }
      else if (this.getAnimated() == false)
      {
        System.out.println("This is not an animated weapon");
      }
    }

    public String toString() {
        String ret = "name: " + this.name + " " +
                "rarity: " + this.rarity + " " +
                "animated: " + this.animated;
        return ret;
    }
}