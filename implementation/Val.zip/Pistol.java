/**
* Author: Gideon Lee
* Date: Jan 27th 2022
* Class: Pistol
* Purpose: One of the 5 weapons provided in this program.
*/

public class Pistol extends Weapon {

    /**
    * Creates a pistol for the player to use with the given info.
    * Inherits from the weapon class.
    */
    public Pistol(String name, int damage, int range, int ammo) {
        super(name, damage, range, ammo);
    }

    //Accessors


    //Mutators

    /**
    * Shoot action
    * Allows player to shoot their weapon.
    */
    public void shoot() {
        if (this.getAmmo() > 0)
        {
          this.setAmmo(this.getAmmo() - 1);
          System.out.println("PEW PEW");
        }
        else if (this.getAmmo() <= 0)
        {
          System.out.println("Nope, reload, you're out of ammo!");
        }
    }
}